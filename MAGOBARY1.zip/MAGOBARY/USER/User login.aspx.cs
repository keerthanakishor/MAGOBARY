﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MAGOBARY.Class;

namespace MAGOBARY.USER
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            userloginClass obj = new userloginClass();
            obj.Email1 = txtuseremail.Text;
            obj.Password = txtuserpass.Text;
            dtReg = obj.ExecuteSelectQueries();

            if (dtReg.Rows.Count > 0)
            {
                Session["Userid"] = Convert.ToInt32(dtReg.Rows[0][0]);
                msg2.Text = "Sucess";
                Response.Redirect("~/USER/UserHome.aspx");

            }
            else
            {
                msg2.Text = "Incorrect Try Again ....!!";
            }
            
           // Response.Redirect("~/USER/UserHome.aspx");
        }
       
    }

}
