﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MAGOBARY.Class;


namespace MAGOBARY.USER
{
    public partial class searchfriends : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                searchfriend();
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
           searchfriend();
            gv_tpc.Visible = true;
        }
        protected void gv_tpc_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gv_tpc.Rows[rowIndex];
                Session["Userid"] = ((HiddenField)gv_tpc.Rows[rowIndex].FindControl("hdnRno")).Value;
                MagobaryClass vc = new MagobaryClass();
                vc.Rno = Convert.ToInt32(Session["Userid"]);

            }
        }
        
        private void searchfriend()
        {
            DataTable dtReg = new DataTable();
            MagobaryClass objmsg = new MagobaryClass();
            objmsg.Fanme = txtfirstname.Text;
            objmsg.Mname = txtmiddlename.Text;
            objmsg.Lname = txtlastname.Text;
            objmsg.Course = txtmescourse.Text;
            objmsg.Email = txtmessageemail.Text;
            dtReg = objmsg.SendMessage();
            if (dtReg.Rows.Count > 0)
            {
                gv_tpc.DataSource = dtReg;
                gv_tpc.DataBind();

            }
          
    }
    }
    }


        
    
