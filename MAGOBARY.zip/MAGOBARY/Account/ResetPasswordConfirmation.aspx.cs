﻿using System.Web.UI;

namespace MAGOBARY.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}