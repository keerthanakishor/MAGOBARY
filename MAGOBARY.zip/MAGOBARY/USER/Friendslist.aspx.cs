﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MAGOBARY.Class;

namespace MAGOBARY.USER
{
    public partial class fullview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadsData();
        }
        private void LoadsData()
        {
            DataTable dtReg = new DataTable();
            MagobaryClass Fobj = new MagobaryClass();
            dtReg = Fobj.Display();
            if(dtReg.Rows.Count > 0)
            {
                gv_TpcReg.DataSource = dtReg;
                gv_TpcReg.DataBind();

            }
        }
        protected void gv_TpcReg_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName == "view")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                Session["Userid"] = ((HiddenField)gv_TpcReg.Rows[rowIndex].FindControl("hdnRno")).Value;
                Response.Redirect("Setting Page.aspx");

            }
        }
    }
}

            