﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using MAGOBARY.Class;

namespace MAGOBARY.USER
{
    public partial class Setting_Page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            load();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            SettingClass objsett = new SettingClass();
            objsett.Ftname = txtftname.Text;
            objsett.Mdname = txtmdname.Text;
            objsett.Ltname = txtltname.Text;
            objsett.Ddob = txtudob.Text;
            objsett.Gender1 = radiomale.Text;
            objsett.Gender1 = radioFemale.Text;
            objsett.Course1 = stream.SelectedItem.Text;
            objsett.Batch1 = txtubatch.Text;
            objsett.Address = txtaddress.Text;
            objsett.Mob = txtmno.Text;
            objsett.Bldg = txtbg.Text;
            objsett.Emaill = txtuemail.Text;
            objsett.Aemail = txtaemail.Text;
            objsett.Uid = Convert.ToString(Session["Userid"]);

            string filename = Path.GetFileName(userphoto.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/Photo") + "\\" + txtftname.Text + ".JPG";
                userphoto.PostedFile.SaveAs(src);
                string picpath = "~/Photo/" + txtftname.Text + ".JPG";
                objsett.Photo = picpath;
            }

            objsett.InsertStudent();





        }
        public void load()
        {
            DataTable dtReg = new DataTable();
            SettingClass obj = new SettingClass();
            obj.Rno = Convert.ToString(Session["Userid"]);
            dtReg = obj.Friendslist();
            if (dtReg.Rows.Count > 0)
            {
                txtftname.Text = Convert.ToString(dtReg.Rows[0]["fname"]);
                txtmdname.Text = Convert.ToString(dtReg.Rows[0]["mname"]);
                txtltname.Text = Convert.ToString(dtReg.Rows[0]["lname"]);
                txtudob.Text = Convert.ToString(dtReg.Rows[0]["dob"]);
                radiomale.Text = Convert.ToString(dtReg.Rows[0]["gender"]);
                radioFemale.Text = Convert.ToString(dtReg.Rows[0]["gender"]);
                stream.Text = Convert.ToString(dtReg.Rows[0]["course"]);
                txtudob.Text = Convert.ToString(dtReg.Rows[0]["batch"]);
                txtaddress.Text = Convert.ToString(dtReg.Rows[0]["address"]);
                txtbg.Text = Convert.ToString(dtReg.Rows[0]["bldg"]);
                txtmno.Text = Convert.ToString(dtReg.Rows[0]["mob"]);
                txtuemail.Text = Convert.ToString(dtReg.Rows[0]["email"]);
                txtaemail.Text = Convert.ToString(dtReg.Rows[0]["aemail"]);
            }
        }
    }
}